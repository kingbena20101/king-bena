# KING BENA — Boutique web

## Ce qui est déjà inclus
- Design blanc + or + noir, responsive mobile/ordinateur
- Barre de recherche
- Filtres par catégorie
- Tri par prix
- Produits temporaires faciles à remplacer
- Panier avec quantités et sauvegarde locale
- Fenêtre de checkout
- Structure prête pour ajouter de vraies photos, tailles, stocks et collections
- Paiement actuellement en MODE DÉMO

## Ouvrir le site
Double-clique sur `index.html` ou ouvre-le dans Chrome.

## Modifier les produits
Dans `script.js`, modifie la liste `products`.

## Important pour les vrais paiements
Le bouton de paiement est une démonstration. Pour accepter réellement les cartes/Apple Pay/etc., il faudra connecter un prestataire de paiement (par exemple Stripe ou Shopify) et un backend sécurisé avant de mettre le site en production.
